//
// Created by xaq on 11/17/17.
//

#include "geometry.h"
#include "vector.h"
#include "map.h"


extern map *base_cells;

void
build_neighbor_list()
{
    cell_t *cell, *neighbor_cell;
    universe_t *univ;
    map_iterator *cell_iter;
    map_entry *entry;
    int surf_index, surfs_sz, surfs_sz2, cells_sz, neighbor_sz;
    vector *vec;

    vec = vector_init(8, sizeof(void *));
    cell_iter = map_get_iter(base_cells);  //构建cell的迭代器
    while((entry = map_iter_next(cell_iter))) {  //当下一个栅元存在的时候
        cell = entry->v.val;  //切换到下个栅元
        univ = cell->parent;  //选择cell所在的上层空间
        cells_sz = univ->cells_sz;  //universe中的栅元数目
        surfs_sz = cell->surfs_sz;  //cell中的曲面数目
        cell->neighbor_lists = (void ***) malloc(surfs_sz * sizeof(void **));  //以surf的数目建立邻居栅元列表
        cell->neighbor_lists_sz = (int *) malloc(surfs_sz * sizeof(int));  //邻居栅元列表中的栅元数目
        for(int i = 0; i < surfs_sz; i++) {  //对于每个曲面
            surf_index = cell->surfs[i];  //得到对应的曲面编号
            for(int j = 0; j < cells_sz; j++) { //对于上层空间中每一个栅元
                neighbor_cell = univ->cells[j];
                surfs_sz2 = neighbor_cell->surfs_sz;  //获得候选栅元的曲面数目
                for(int k = 0; k < surfs_sz2; k++) {
                    if(surf_index + neighbor_cell->surfs[k] == 0)  //如果候选栅元也包含同样的曲面
                        vector_push_back(vec, &neighbor_cell);
                }
            }

            neighbor_sz = vector_size(vec);  //得到邻居栅元列表的栅元数目
            cell->neighbor_lists_sz[i] = neighbor_sz;
            cell->neighbor_lists[i] = (void **) malloc(neighbor_sz * sizeof(void *));  //将邻居栅元列表添加到cell的属性中
            memcpy(cell->neighbor_lists[i], vec->start, sizeof(void *) * neighbor_sz);  //从vec中复制邻居栅元信息到cell的neighbour list中
            vector_clear(vec);  //清空原向量
        }
    }

    map_release_iter(cell_iter);
    vector_free(vec);
    free(vec);
}
