//
// Created by xaq on 9/2/17.
//

#include "IO_releated.h"


extern IOfp_t base_IOfp;

void
check_IO_file(int argc,
              char *argv[])
{
    char mat_fn[MAX_FILENAME_LENGTH];
    char tally_fn[MAX_FILENAME_LENGTH];

    /* important: initial allocation */
    if(argc >= 3) {
        if(strlen(argv[1]) < MAX_FILENAME_LENGTH && strlen(argv[2]) < MAX_FILENAME_LENGTH) {
            strcpy(base_IOfp.inp_file_name, argv[1]);  //复制字符串
            strcpy(base_IOfp.opt_file_name, argv[2]);
            strcpy(base_IOfp.neural_data, argv[3]);
        } else {
            puts("filename too long.");
            release_resource();
            exit(0);
        }

    } else if(argc == 2) {
        if(strlen(argv[1]) < MAX_FILENAME_LENGTH)  //判断文件名是否超过最大长度
            strcpy(base_IOfp.inp_file_name, argv[1]);
        else {
            puts("filename too long.");
            release_resource();
            exit(0);
        }
        strcpy(base_IOfp.opt_file_name, base_IOfp.inp_file_name);  //拷贝用户定义的输出文件名
        strcat(base_IOfp.opt_file_name, ".out");
        strcpy(base_IOfp.neural_data, "neural.csv");
    } else if(argc == 1) {
        strcpy(base_IOfp.inp_file_name, "inp");  //如果用户未定义输出文件名，则按照默认的输出
        strcpy(base_IOfp.opt_file_name, "inp.out");
        strcpy(base_IOfp.neural_data, "neural.csv");
    }

    strcpy(mat_fn, base_IOfp.inp_file_name);  //输出mat和tally文件
    strcat(mat_fn, ".mat");
    strcpy(tally_fn, base_IOfp.inp_file_name);
    strcat(tally_fn, ".tally");

    base_IOfp.inp_fp = fopen(base_IOfp.inp_file_name, "rb");
    if(!base_IOfp.inp_fp) {
        printf("%s does not exist.\n", base_IOfp.inp_file_name);
        release_resource();
        exit(0);

    }

    base_IOfp.opt_fp = fopen(base_IOfp.opt_file_name, "wb");
    base_IOfp.mat_fp = fopen(mat_fn, "wb");
    //    base_IOfp.tally_fp = fopen(tally_fn, "wb");

    base_IOfp.neural_fp = fopen(base_IOfp.neural_data, "wb");
}
