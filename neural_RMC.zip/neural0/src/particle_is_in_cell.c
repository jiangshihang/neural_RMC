//
// Created by xaq on 2018/1/29.
//

#include "cell.h"
#include "surface.h"


/* -------------------------- private prototypes ---------------------------- */
static inline bool
_has_same_sign(int a,
               int b);

static bool
_simple_par_in_cell(const cell_t *obj,
                    const double *pos,
                    const double *dir);

static bool
_complex_par_in_cell(const cell_t *obj,
                     const double *pos,
                     const double *dir);

/* ----------------------------- API implementation ------------------------- */

/* ***************************************************************************
 * 输入：obj: 当前要判断的cell
 *      pos[3], dir[3]: 粒子坐标和方向
 * 输出: 粒子是否在当前cell
 * ***************************************************************************/
bool
particle_is_in_cell(const cell_t *obj,
                    const double pos[3],
                    const double dir[3])
{
    if(obj->simple) return _simple_par_in_cell(obj, pos, dir);      //如果是简单栅元则按照简单栅元处理
    else return _complex_par_in_cell(obj, pos, dir);    //否则称为复杂栅元
}

/* ------------------------ private API implementation ---------------------- */
inline bool
_has_same_sign(int a,
               int b)
{
    return ((a ^ b) & 0x80000000) == 0;
}

bool
_simple_par_in_cell(const cell_t *obj,
                    const double pos[3],
                    const double dir[3])
{
    bool in_cell = true;
    int surf_index = 0;
    surface_t *surf;
    int surf_sense;
    int surfs_sz = obj->surfs_sz;

    for(int i = 0; i < surfs_sz; i++) { //对于栅元的每个曲面
        surf_index = obj->surfs[i];     //调出曲面编号
        surf = obj->surfs_addr[i];      //找到曲面实例
        surf_sense = calc_surf_sense(surf, pos, dir);   //判断粒子位置与曲面的关系
        in_cell = _has_same_sign(surf_index, surf_sense);      //判断是否同号
        if(!in_cell) break; //由于简单栅元是只含有曲面的交的栅元，因此只要对于一个曲面不符合要求就退出
    }
    return in_cell;
}

bool
_complex_par_in_cell(const cell_t *obj,
                     const double *pos,
                     const double *dir) //输入粒子的位置、运动方向及栅元信息
{   //利用栈可以对RPN表达式进行处理
    bool in_cell;   //粒子是否在栅元内
    bool st[16];
    int i_stack;
    int surf_index;     //曲面编号
    surface_t *surf;
    int surf_sense;
    int index = 0;
    register char *c;  //*c是一个指针，指向布尔定义中的一个编号或符号

    c = obj->rpn;    /* 面布尔表达式转换而来的RPN表达式 */
    i_stack = -1;

    while(*c != '\0') {     //当c指向布尔定义中的内容时
        if(ISNUMBER(*c)) {  //如果c指向的是曲面编号
            i_stack++;
            surf_index = 0;
            do {            //一直读取完该编号，得到曲面编号的值
                surf_index *= 10;
                surf_index += *c - '0';
                c++;
            } while(ISNUMBER(*c));
            surf = obj->surfs_addr[index++];
            surf_sense = calc_surf_sense(surf, pos, dir);   //计算粒子与曲面的距离
            in_cell = _has_same_sign(surf_index, surf_sense);   //通过判断正负关系确定粒子是否在栅元内
            st[i_stack] = in_cell;
        } else if(*c == '-') {      //如果指向一个负的运算符
            i_stack++;
            surf_index = 0;
            c++;
            while(ISNUMBER(*c)) {
                surf_index *= 10;
                surf_index += *c - '0';
                c++;
            }
            surf = obj->surfs_addr[index++];
            surf_index = (~surf_index) + 1;
            surf_sense = calc_surf_sense(surf, pos, dir);
            in_cell = _has_same_sign(surf_index, surf_sense);
            st[i_stack] = in_cell;
        } else if(*c == '&') {
            st[i_stack - 1] = st[i_stack] && st[i_stack - 1];
            i_stack--;
            c++;
        } else if(*c == ':') {
            st[i_stack - 1] = st[i_stack] || st[i_stack - 1];
            i_stack--;
            c++;
        } else if(*c == '!') {
            st[i_stack] = !st[i_stack];
            c++;
        } else c++;
    }

    /* i_stack等于-1只可能是因为RPN表达式为空；如果RPN表达式非空的话，最后的结果就是st[0] */
    in_cell = (i_stack == -1) ? true : st[0];

    return in_cell;
}

//bool _complex_par_in_cell(const cell_t *obj, const double pos[3], const double dir[3]){
//    bool st[16];
//    char symbols[16];
//    int i_stack, surfs_ptr, symbols_ptr;
//    surface_t *surf;
//    int *surfs_sense, *surfs_index;
//    int surfs_sz;
//    int symbol_cnt;
//    char *c;
//
//    surfs_sz = obj->surfs_sz;
//    surfs_sense = (int *) malloc(surfs_sz * sizeof(int));
//    surfs_index = obj->surfs;
//
//    for(int i = 0; i < surfs_sz; i++){
//        surf = obj->surfs_addr[i];
//        surfs_sense[i] = calc_surf_sense(surf, pos, dir);
//    }
//
//    c = obj->rpn;
//    symbol_cnt = 0;
//
//    while(*c != '\0'){
//        if(*c == '&' || *c == ':' || *c == '!')
//            symbols[symbol_cnt++] = *c;
//        c++;
//    }
//
//    i_stack = -1;
//    surfs_ptr = 0;
//    symbols_ptr = 0;
//
//    while(surfs_ptr < surfs_sz || symbols_ptr < symbol_cnt){
//        switch(symbols[symbols_ptr++]){
//            case '&':
//                if(surfs_ptr < surfs_sz){
//                    i_stack++;
//                    st[i_stack++] = _has_same_sign(surfs_sense[surfs_ptr], surfs_index[surfs_ptr]);
//                    surfs_ptr++;
//                    st[i_stack] = _has_same_sign(surfs_sense[surfs_ptr], surfs_index[surfs_ptr]);
//                    surfs_ptr++;
//                }
//                st[i_stack - 1] = st[i_stack] && st[i_stack - 1];
//                i_stack--;
//                break;
//            case ':':
//                if(surfs_ptr < surfs_sz){
//                    i_stack++;
//                    st[i_stack++] = _has_same_sign(surfs_sense[surfs_ptr], surfs_index[surfs_ptr]);
//                    surfs_ptr++;
//                    st[i_stack] = _has_same_sign(surfs_sense[surfs_ptr], surfs_index[surfs_ptr]);
//                    surfs_ptr++;
//                }
//                st[i_stack - 1] = st[i_stack] || st[i_stack - 1];
//                i_stack--;
//                break;
//            default:
//                st[i_stack] = !st[i_stack];
//                break;
//        }
//    }
//    free(surfs_sense);
//    return st[i_stack];
//}