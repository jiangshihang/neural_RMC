//
// Created by xaq on 11/15/17.
//

#include "neutron_transport.h"
#include "nuclide.h"
#include "RNG.h"


void
treat_implicit_capture(particle_status_t *par_status)
{
    nuc_xs_t *cur_nuc_xs;
    double wgt_survival;

    cur_nuc_xs = par_status->nuc_xs;    //当前核素的状态
    par_status->wgt *= (ONE - (cur_nuc_xs->abs + cur_nuc_xs->fis) / cur_nuc_xs->tot);
    //更新粒子的权重，减去粒子被吸收或参与裂变反应的概率
    if(par_status->wgt > WGT_CUTOFF) return;

    wgt_survival = TWO * WGT_CUTOFF;    //如果此时粒子的权重小于某个截止值，则通过抽样来决定这个粒子能否继续幸存下去
    if(get_rand() < par_status->wgt / wgt_survival)
        par_status->wgt = wgt_survival; //若粒子能够幸存，将它的权重设置成截止值的两倍
    else par_status->is_killed = true;  //否则粒子被杀死
}