#include <Python.h>
#include <stdio.h>
#include "particle_status.h"

//本文件是用神经网络预测得到粒子进入栅元号的文��?
int use_neural_net(double pos_x,
                   double pos_y,
                   double pos_z,
                   double dir_x,
                   double dir_y,
                   double dir_z,
                   double erg){

    PyObject* pMod = NULL;
    PyObject* pFunc = NULL;
    PyObject* pParm = NULL;
    PyObject* pRetVal = NULL;
    int iRetVal = -999;
    char* modulName = "load_model";
    char* funcName = "evaluate";
    Py_Initialize();
        if(!Py_IsInitialized()){
            return -1;
        }
        PyRun_SimpleString("import sys");
        PyRun_SimpleString("sys.path.append('./')");

    pMod = PyImport_ImportModule(modulName);
    if(!pMod)
    {
        return -1;
    }
    pFunc = PyObject_GetAttrString(pMod, funcName);
    if(!pFunc)
    {
        return -2;
    }
    pParm = PyTuple_New(7);

    PyTuple_SetItem(pParm,0, Py_BuildValue("f",pos_x));
    PyTuple_SetItem(pParm,1, Py_BuildValue("f",pos_y));
    PyTuple_SetItem(pParm,2, Py_BuildValue("f",pos_z));
    PyTuple_SetItem(pParm,3, Py_BuildValue("f",dir_x));
    PyTuple_SetItem(pParm,4, Py_BuildValue("f",dir_y));
    PyTuple_SetItem(pParm,5, Py_BuildValue("f",dir_z));
    PyTuple_SetItem(pParm,6, Py_BuildValue("f",erg));

    //puts("111\n");
    pRetVal = PyEval_CallObject(pFunc, pParm);
    PyArg_Parse(pRetVal, "i", &iRetVal);

    return iRetVal;
}

void renew_par_status(particle_status_t *par_status, int cell_rank){
    //本函数用于从cell的rank来定位cell

}
