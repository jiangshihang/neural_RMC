//
//  Created by xaq on 10/27/17.
//

#include "geometry.h"


extern universe_t *root_universe;

cell_t *//返回一个cell结构体
locate_particle(particle_status_t *par_status,
                universe_t *start_univ, //起始空间？
                const double *pos,
                const double *dir)
{
    universe_t *univ, *lat_univ;
    cell_t *cell, *found_cell;
    int level, univ_sz, cell_sz;
    double local_pos_temp[3];
    double local_dir_temp[3];

    for(int i = 0; i < 3; i++) {
        local_pos_temp[i] = pos[i];
        local_dir_temp[i] = dir[i];
    }

    univ = start_univ;
    found_cell = NULL;
    level = 0;

    /* 清空当前univs和cells，全部重新定位 */
    if(univ == root_universe)   //如果是实际空间
        par_status->loc_sz = 0;
    univ_sz = par_status->loc_sz;   //该空间是第几层空间
    cell_sz = par_status->loc_sz;

    while(1) {
        if(++level > 99) {      //如果超过99层空间
            puts("terminate locating particle because of too many levels (>99).");
            return NULL;
        }

        par_status->loc_univs[univ_sz++] = univ;    //新的一层universe

        if(univ->lattice_type) {    /* current universe has lattice structure */
            int lat_index = find_lat_index(univ, local_pos_temp, local_dir_temp);//找到栅元在重复序列中的编号
            if(lat_index < 0) { //说明粒子跳出了重复结构
                printf("failed to locate particle, pos = %lf %lf %lf, dir = %lf %lf %lf\n", pos[0], pos[1], pos[2],
                       dir[0], dir[1], dir[2]);
                break;
            }

            par_status->loc_cells[cell_sz++] = lat_index;   //将得到的编号放入新一层栅元编号数组中
            lat_univ = univ->filled_lat_univs[lat_index - 1];
            move_to_origin_lat(univ, lat_index, local_pos_temp);    //改变local_pos_temp
            trans_univ_coord(lat_univ, local_pos_temp, local_dir_temp); //将粒子坐标转换回lat_univ的坐标
            univ = lat_univ;    //将空间设为lat_univ
        } else {    /* current universe has some cells and has no lattice */
            for(int i = 0; i < univ->cells_sz; i++) {   //对当前universe中的每个cell
                cell = univ->cells[i];
                if(particle_is_in_cell(cell, local_pos_temp, local_dir_temp)) { //如果粒子在该cell中
                    par_status->loc_cells[cell_sz++] = i;   //记入cell的编号
                    if(cell->fill) {    /* current cell has a universe filled in */
                        trans_univ_coord(cell->fill, local_pos_temp, local_dir_temp);   //转换坐标为fill的universe的坐标
                        univ = cell->fill;
                        break;  //回到while的大循环
                    } else {    /* current cell is a simple cell which has no fills */
                        for(int j = 0; j < 3; j++) {
                            par_status->loc_pos[j] = local_pos_temp[j];
                            par_status->loc_dir[j] = local_dir_temp[j];
                        }
                        found_cell = cell;
                        goto END;   //结束while循环
                    }
                }
            }
        }
    }

END:
    if(!found_cell) //如果没有找到
        puts("failed to locate particle.");

    par_status->loc_sz = univ_sz;   //更新loc_sz
    return found_cell;
}
