#include "particle_status.h"
#include "list.h"

listnode_t *listnode_init(particle_status_t value){
    listnode_t *listnode = malloc(sizeof(particle_status_t*));
    listnode->data = value;
    listnode->pred = NULL;
    listnode->succ = NULL;
    return listnode;
}

listnode_t* insertAsSucc(listnode_t *a, particle_status_t* e){
  listnode* x = new listnode_init(e);
  a->succ->pred = x;
  a->succ = x;
  return x;
}

listnode_t* insertAsPred(listnode_t *a, particle_status_t* e){
  listnode* x = new listnode_init(e);
  a->pred->succ = x;
  a->pred = x;
  return x;
}

list_t* list_init(){
  listnode_t *header = listnode_init(NULL);
  listnode_t *trailer = listnode_init(NULL);
  header->succ=trailer;
  header->pred=NULL;
  trailer->pred=header;
  trailer->succ=NULL;
}

void listnode_remove(listnode_t *node){
  node->pred->succ=node->succ;
  node->succ->pred=node->pred;
  delete node;
}

listnode_t *listnode_insert(list_t *list, particle_status_t *value){
  return list->trailer->insertAsPred(value);
}
