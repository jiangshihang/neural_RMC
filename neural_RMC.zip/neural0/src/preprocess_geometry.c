//
// Created by xaq on 2018/2/3.
//

#include "geometry.h"
#include "map.h"
#include "cell.h"
#include "vector.h"


extern map *base_univs;
extern map *base_cells;
extern map *base_surfs;
extern map *base_mats;
universe_t *root_universe;

int
preprocess_geometry()
{
    universe_t *univ;
    cell_t *cell;
    map_entry *entry;
    map_iterator *cell_iter, *univ_iter;
    int filled_univ_index;
    int surfs_sz, filled_lat_univs_sz;
    int surf_index, mat_index;
    vector *cell_rank;
    cell_rank = vector_init(5,sizeof(cell_t*));   //cell_rank是一个以cell为元素的vector

    cell_iter = map_get_iter(base_cells);  //从base cells的map中得到迭代器
    while((entry = map_iter_next(cell_iter))) {  //对cell进行迭代
        puts("\n******** cell reading ********\n");
        cell = entry->v.val;
        /* 调整cell->fill指针和univ->parent指针 */
        if(cell->fill) {
            filled_univ_index = (int) cell->fill;
            univ = map_get(base_univs, filled_univ_index);  //从universe的map中获取填充cell的universe
            cell->fill = univ;
            univ->parent = cell;  //调整之后cell和填充cell的universe之间的关系完全建立
        }

        /* 调整cell->surfs_addr */
        surfs_sz = cell->surfs_sz;  //得到cell包含的面的数目
        cell->surfs_addr = (void **) malloc(surfs_sz * sizeof(void *));
        for(int i = 0; i < surfs_sz; i++) {  //对于每个cell
            surf_index = abs(cell->surfs[i]);
            cell->surfs_addr[i] = map_get(base_surfs, surf_index);  //获取对应的surf地址
        }

        /* 调整cell->mat指针 */
        mat_index = (int) cell->mat;
        cell->mat = map_get(base_mats, mat_index);
        vector_push_back(cell_rank, cell);
    }

    univ_iter = map_get_iter(base_univs);
    while((entry = map_iter_next(univ_iter))) {  //对universe进行迭代
        univ = entry->v.val;
        /* 调整univ->filled_lat_univs */
        if(univ->filled_lat_univs) {  //如果是重复结构填充
            filled_lat_univs_sz = univ->scope[0] * univ->scope[1];  //计算得到填充栅元的数目
            if(univ->lattice_type == 1) filled_lat_univs_sz *= univ->scope[2];
            for(int i = 0; i < filled_lat_univs_sz; i++) {  //对于每个重复结构中的栅元
                filled_univ_index = (int) univ->filled_lat_univs[i];
                univ->filled_lat_univs[i] = map_get(base_univs, filled_univ_index);  //获取填充的所有universe实例的地址
            }
        }
    }

    map_release_iter(cell_iter);
    map_release_iter(univ_iter);

    root_universe = map_get(base_univs, 0);
    /* 构建邻居栅元 */
    build_neighbor_list();
    return 0;
}
