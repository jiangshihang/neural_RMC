#include "particle_status.h"


typedef struct{
  particle_status_t *data;
  listnode_t *pred;
  listnode_t *succ;

}listnode_t;


typedef struct{
  listnode_t *header;
  listnode_t *trailer;
  
}

listnode_t *listnode_init(particle_status_t value);

listnode_t* insertAsSucc(listnode_t *a, particle_status_t* e);

listnode_t* insertAsPred(listnode_t *a, particle_status_t* e);

list_t* list_init();

void listnode_remove(listnode_t *node);

listnode_t *listnode_insert(list_t *list, particle_status_t *value);
