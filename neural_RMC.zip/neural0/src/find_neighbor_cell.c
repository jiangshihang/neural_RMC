//
// Created by xaq on 11/18/17.
//

#include "geometry.h"


void
find_neighbor_cell(particle_status_t *par_status)
{
    double loc_pos[3], loc_dir[3];
    int lat_index;
    bool found = false;
    int level = par_status->bound_level;
    cell_t *found_cell = NULL;//指向目标栅元的指针
    universe_t *univ = par_status->loc_univs[level];
    universe_t *filled_univ = NULL;

    par_status->loc_sz = level + 1;	//以上两个lock的实际size

    for(int i = 0; i < 3; i++) {
        loc_pos[i] = par_status->loc_pos[i];
        loc_dir[i] = par_status->loc_dir[i];
    }

    if(univ->lattice_type) {//如果是重复序列填充
        lat_index = offset_neighbor_lat(univ, par_status->loc_cells[level], par_status->lat_bound_surf, loc_pos);
        //得到重复序列中的新的栅元编号
        if(lat_index >= 0) {    //如果粒子没有离开重复序列区域
            par_status->loc_cells[level] = lat_index;   //将粒子状态结构体中的该层栅元编号更新
            filled_univ = univ->filled_lat_univs[lat_index - 1];    //找到该栅元对应的坐标
            trans_univ_coord(filled_univ, loc_pos, loc_dir);        //转换粒子在空间中的坐标
            found_cell = locate_particle(par_status, filled_univ, loc_pos, loc_dir);    //找出粒子所在的栅元
            if(found_cell) found = true;
        }
    } else {
        cell_t *cell, *neighbor_cell;
        int bound_index = par_status->bound_index;  //粒子当前要穿出的面的编号
        cell = univ->cells[par_status->loc_cells[level]];   //粒子当前所在的栅元
        neighbor_cell = NULL;
        int neighbor_sz = cell->neighbor_lists_sz[bound_index];
        for(int i = 0; i < neighbor_sz; i++) {  //分析粒子要穿出的面的相邻栅元
            neighbor_cell = cell->neighbor_lists[bound_index][i];   
            if(particle_is_in_cell(neighbor_cell, loc_pos, loc_dir)) {  //如果粒子在该相邻栅元中
                found = true;
                break;
            }
        }

        if(found) {
            /* 不得已而为之，因为loc_cells存储的是当前universe中的第几个，而不是直接存储的cell_index */
            for(int i = 0; i < univ->cells_sz; i++)     //对于该空间的每个栅元
                if(neighbor_cell == univ->cells[i]) {   
                    par_status->loc_cells[level] = i;   //存储该栅元在universe中的编号
                    break;
                }

            found_cell = neighbor_cell;     //得到了目标栅元
            filled_univ = neighbor_cell->fill;
            if(filled_univ) {    /* neighbor_cell is a complex cell with universe filled */
                trans_univ_coord(filled_univ, loc_pos, loc_dir);
                found_cell = locate_particle(par_status, filled_univ, loc_pos, loc_dir);    //继续向下寻找
            }
        }
    }

    if(!found)  //从第零层重新开始寻找
        found_cell = locate_particle(par_status, par_status->loc_univs[0], par_status->pos, par_status->dir);

    par_status->cell = found_cell;      //将粒子状态结构体中的该层栅元编号更新
}