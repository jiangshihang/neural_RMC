//
// Created by 叶鑫 on 2017/11/9.
//

#include "neutron_transport.h"
#include "RNG.h"
#include "material.h"
#include "acedata.h"


extern acedata_t base_acedata;
extern nuc_xs_t *base_nuc_xs;

double
sample_free_fly_dis(particle_status_t *par_status,
                    bool erg_changed)
{
    mat_t *mat;				//材料
    nuclide_t *nuc, *sab_nuc;	//核素
    nuc_xs_t *cur_nuc_xs;	//
    double nuc_atom_den;

    /***********************************************************************
     * 如果粒子当前的材料以及材料温度与上次相比都没有发生变化，那么直接使用上一次的计算结果
     * 即可，不用重新计算。这种情况在大规模的重复几何结构中比较常见，采取这种方法，可以提高
     * 重复几何结构的计算的效率
     ***********************************************************************/
    if(!erg_changed && !par_status->mat_changed && !par_status->cell_tmp_changed)
        goto END;

    /* vacuum material */
    if(par_status->mat == NULL) {   //若为真空，则密度和截面都为零
        par_status->macro_tot_cs = ZERO_ERG;
        par_status->macro_nu_fis_cs = ZERO;
        goto END;
    }

    par_status->macro_tot_cs = ZERO;
    par_status->macro_nu_fis_cs = ZERO;

    mat = par_status->mat;

    /*************************************************
     * calculate total cross section of each nuclide,
     * and then, sum them up.
     *************************************************/

    for(int i = 0; i < mat->tot_nuc_num; i++) {     //对于当前材料所包含的每一种核素
        nuc = mat->nucs[i];
        sab_nuc = mat->sab_nuc;
        nuc_atom_den = mat->nuc_atom_den[i];
        cur_nuc_xs = &base_nuc_xs[nuc->xs];

        if(sab_nuc && (sab_nuc->zaid != nuc->zaid || par_status->erg >= mat->sab_nuc_esa))
            sab_nuc = NULL;     //没有热核截面

        get_nuc_tot_fis_cs(&base_acedata, nuc, sab_nuc, cur_nuc_xs, par_status->erg, par_status->cell_tmp);
        //得到该核素总的裂变截面

        par_status->macro_tot_cs += nuc_atom_den * cur_nuc_xs->tot; //总的宏观截面加上核素的截面乘以原子密度
        if(GT_ZERO(cur_nuc_xs->fis))    //如果裂变截面大于0，在总的裂变截面中加入该核素的裂变截面
            par_status->macro_nu_fis_cs += nuc_atom_den * cur_nuc_xs->fis * cur_nuc_xs->nu;
    }

    if(!GT_ZERO(par_status->macro_tot_cs)) {    //如果总的宏观截面过小可忽略
        par_status->macro_tot_cs = ZERO_ERG;
        par_status->macro_nu_fis_cs = ZERO;
    }
END:
    return -log(get_rand()) / par_status->macro_tot_cs;     //  抽样得到粒子的飞行距离
}