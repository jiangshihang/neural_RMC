//
// Created by xaq on 10/27/17.
//

#include <stdio.h>
#include "neutron_transport.h"
#include "criticality.h"
#include "geometry.h"
#include "use_neural_net.h"//需要编写相应的文件？

extern criti_t base_criti;

void read_from_output(particle_status_t *par_status){
   FILE *fw = fopen("result.txt", "r" );
   fscanf(fw,"%d",&par_status->cell);
}

void
geometry_tracking(particle_status_t *par_status, int cycle_num)
{
    double FFL;    /* free fly length */
    double DTB;    /* distance to boundary */
    double distance;
    int iter_cnt = 0;
    int cell_rank = 0;
    bool par_on_surf = false;
    par_status->surf = 0;    /* particle is not on surface at the beginning */

    do {
        if(iter_cnt++ > MAX_ITER) {
            par_status->is_killed = true;
            puts("too many times of surface crossing.");
            base_warnings++;
            return;
        }

        if(par_on_surf){
            if(cycle_num <= base_criti.inactive_cycle_num)
                find_next_cell(par_status);//找到下一个栅元，应当返回栅元编号
            /*设想的第一步是，在这里设一个分支，即当粒子所在的代大于某个设定值时，转入用神经网络预测的模式。此时必须保证
            的是，粒子进入的栅元必须是实际存在的。只要这一点满足，理论上程序就能够运行下去。
            */
            else{
                /*use_neural_net(par_status->pos[0],
                               par_status->pos[1],
                               par_status->pos[2],
                               par_status->dir[0],
                               par_status->dir[1],
                               par_status->dir[2],
                               par_status->erg);
                renew_par_status(par_status, cell_rank);*/
                //puts("using neural net...");
                read_from_output(par_status);  //对于活跃代的粒子，之前已经集中利用神经网络模型预测了粒子将进入的栅元，并输出为文件，
                                     //因此只需要从文件中读取即可
            }
        }

        if(par_status->is_killed)
            return;

        DTB = calc_dist_to_bound(par_status);
        /*得到粒子和边界的距离，这个也可以用神经网络来进行预测，这样就可以避免发生预测栅元不准确时，粒子的坐标没有落在栅
        元内的情况。
        */
        if(LT_ZERO(DTB)) {  //若距离小于零，说明粒子is killed
            puts("failed to calculate distance to boundary.");
            par_status->is_killed = true;
            DTB = ZERO;
        }

        FFL = sample_free_fly_dis(par_status, !par_on_surf);//抽样得到粒子自由飞行的距离

        if(FFL >= DTB) {
            par_on_surf = true;//粒子能够经过边界
            distance = DTB;
        } else {
            par_on_surf = false;
            distance = FFL;
        }

        Estimate_keff_tl(par_status->wgt, par_status->macro_nu_fis_cs, distance);//计算反应性（宏定义）

        Fly_by_length(distance);    //更新粒子在universe0和当前空间中的位置
    } while(par_on_surf);   //当粒子没有穿过边界，表明粒子发生了碰撞或者is killed，若穿过边界则继续追踪直到发生碰撞

    Estimate_keff_col(par_status->wgt, par_status->macro_nu_fis_cs, par_status->macro_tot_cs);
}
