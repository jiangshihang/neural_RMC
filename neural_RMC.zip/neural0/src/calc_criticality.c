//
// Created by xaq on 10/26/17.
//

#include "criticality.h"
#include "RNG.h"
#include "IO_releated.h"


extern criti_t base_criti;

void
calc_criticality()
{
    init_fission_src();  //初始化裂变源

    particle_status_t par_status;
    for(int cyc = 1; cyc <= base_criti.tot_cycle_num; cyc++) {      //对于每一代中子
        for(int neu = 1; neu <= base_criti.cycle_neutron_num; neu++) {      //对于每一代中的每一个中子
            get_rand_seed();

            /* sample source particle */
            sample_fission_src(&par_status);    //抽样获取初始源的位置
            if(cyc > base_criti.inactive_cycle_num)
              printf("this is cyc %d, neu %d\n",cyc,neu);
            /* neutron history */
            track_history(&par_status, cyc);  //追踪中子历史
        }
        process_cycle_end(cyc);  //每一代结束后处理相关数据
    }
    output_summary();
}
