#ifndef NEURAL_NET_H
#define NEURAL_NET_H

#include <stdlib.h>

int use_neural_net(double pos_x,
                   double pos_y,
                   double pos_z,
                   double dir_x,
                   double dir_y,
                   double dir_z,
                   double erg);


void renew_par_status(particle_status_t
              *par_status, int cell_rank);

#endif
