//
// Created by xaq on 2018/1/29.
//

#include "universe.h"


void
trans_univ_coord(universe_t *obj,
                 double pos[3],
                 double dir[3])
{
    if(obj->is_moved)   //如果被平移过
        for(int i = 0; i < 3; i++) 
            pos[i] -= obj->origin[i];   //将粒子坐标移动平移的距离

    if(obj->is_rotated) {   //如果有旋转，与平移同
        double pos_temp[3];
        double dir_temp[3];
        for(int i = 0; i < 3; i++) {
            pos_temp[i] = pos[i];
            dir_temp[i] = dir[i];
        }

        for(int i = 0; i < 3; i++) {
            pos[i] = 0;
            dir[i] = 0;
            for(int j = 0; j < 3; j++) {
                pos[i] += obj->rotation[i][j] * pos_temp[j];
                dir[i] += obj->rotation[i][j] * dir_temp[j];    //同时改变粒子的方向
            }
        }
    }
}