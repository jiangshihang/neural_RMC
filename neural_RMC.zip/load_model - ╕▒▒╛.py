# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 21:39:44 2018

@author: dell
"""

import tensorflow as tf
import numpy as np

def evaluate(x1,x2,x3,x4,x5,x6,x7):
	X = [[x1,x2,x3,x4,x5,x6,x7]]
	X = np.array(X)
	#print(X)
	
	x = tf.placeholder(tf.float32,shape=(None,7))
	y = tf.placeholder(tf.float32,[None,1])
	print(x)
	
	Weights_L1 = tf.Variable(tf.random_normal([7,10]))
	biases_L1 = tf.Variable(tf.zeros([1,10])) 
	Wx_plus_b_L1 = tf.matmul(x,Weights_L1)+biases_L1
	L1 = tf.nn.relu(Wx_plus_b_L1) 
	
	Weights_mid = tf.Variable(tf.random_normal([10,10]))
	biases_mid = tf.Variable(tf.zeros([1,10]))
	Wx_plus_b_mid = tf.matmul(L1,Weights_mid)+biases_mid
	mid = tf.nn.relu(Wx_plus_b_mid)
	
	Weights_L2 = tf.Variable(tf.random_normal([10,1])) 
	biases_L2 = tf.Variable(tf.zeros([1,1]))
	Wx_plus_b_L2 = tf.matmul(mid,Weights_L2)+biases_L2
	prediction = tf.nn.sigmoid(Wx_plus_b_L2)
	
	loss = tf.reduce_mean(tf.square(y-prediction))
	
	train_step = tf.train.GradientDescentOptimizer(0.001).minimize(loss) 
	
	with tf.Session() as sess:
		sess.run(tf.global_variables_initializer())
		saver = tf.train.import_meta_graph('ckpt/mnist.ckpt-7.meta')
		saver.restore(sess, tf.train.latest_checkpoint("ckpt/"))
		y = sess.run(prediction,feed_dict = {x:X})
		print(y)
	
	#print(11)
	return y
