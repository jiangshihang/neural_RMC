# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 21:39:44 2018

@author: dell
"""

import tensorflow as tf
import numpy as np
from pandas import read_csv


X = read_csv('neutron_data.csv',names=['pos_x','pos_y','pos_z','dir_x','dir_y',
                                   'dir_z','erg'],
            usecols = [0,1,2,3,4,5,6])
X = np.array(X)
#print(X)

x = tf.placeholder(tf.float32,shape=(None,7))
y = tf.placeholder(tf.float32,[None,1])
print(x)

Weights_L1 = tf.Variable(tf.random_normal([7,10]))
biases_L1 = tf.Variable(tf.zeros([1,10])) 
Wx_plus_b_L1 = tf.matmul(x,Weights_L1)+biases_L1
L1 = tf.nn.relu(Wx_plus_b_L1) 

Weights_mid = tf.Variable(tf.random_normal([10,10]))
biases_mid = tf.Variable(tf.zeros([1,10]))
Wx_plus_b_mid = tf.matmul(L1,Weights_mid)+biases_mid
mid = tf.nn.relu(Wx_plus_b_mid)

Weights_L2 = tf.Variable(tf.random_normal([10,1])) 
biases_L2 = tf.Variable(tf.zeros([1,1]))
Wx_plus_b_L2 = tf.matmul(mid,Weights_L2)+biases_L2
prediction = tf.nn.sigmoid(Wx_plus_b_L2)

loss = tf.reduce_mean(tf.square(y-prediction))

train_step = tf.train.GradientDescentOptimizer(0.001).minimize(loss) 

f = open('result.txt','w')

with tf.Session() as sess:
	sess.run(tf.global_variables_initializer())
	saver = tf.train.import_meta_graph('ckpt/mnist.ckpt-7.meta')
	saver.restore(sess, tf.train.latest_checkpoint("ckpt/"))
	y = sess.run(prediction,feed_dict = {x:X})
	f.write('%d\n'%y[0][0])

f.close()


