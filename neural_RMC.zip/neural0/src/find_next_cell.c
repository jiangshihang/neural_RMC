//
// Created by xaq on 11/14/17.
//
#include "IO_releated.h"
#include "geometry.h"


#define REFLECTIVE    1
#define CROSSING      0

extern IOfp_t base_IOfp;

void
find_next_cell(particle_status_t *par_status)
{
    universe_t *univ;//指向结构体universe_t的指针
    cell_t *cell;
    surface_t *surf;
    void *prev_mat;
    double prev_cell_tmp;//之间cell的温度
    int level = par_status->bound_level;



    univ = par_status->loc_univs[level];//到当前粒子距离最短的面所在的universe
    prev_mat = par_status->mat;
    prev_cell_tmp = par_status->cell_tmp;


    fprintf(base_IOfp.neural_fp, "%f,%f,%f,%f,%f,%f,%f,",par_status->loc_pos[0],par_status->loc_pos[1],par_status->loc_pos[2],
        par_status->dir[0],par_status->dir[1],par_status->dir[2],par_status->erg);
    /*fprintf(base_IOfp.neural_fp, "%d,%d,%d,%d",par_status->bound_level,
        univ->id,par_status->loc_cells[par_status->bound_level]/17,par_status->loc_cells[par_status->bound_level]%17);*/
    if(univ->lattice_type)//如果是重复填充结构
    {
        find_neighbor_cell(par_status);//调用find_neighbour_cell函数
    }
    /*设想的第二步是，在此处不是将这些量输出到文件中，而是直接输出到搭建的神经网络框架中，用来训练神经网络
    */

    else {
        cell = univ->cells[par_status->loc_cells[level]];
        surf = cell->surfs_addr[par_status->bound_index];

        switch(surf->bc) {
        case CROSSING:find_neighbor_cell(par_status);
            break;
        case REFLECTIVE: {
            /* TODO: 当cell为凹多边形时，可能存在假的反射面，这时应该继续输运而不进行反射 */
            reflect_par(surf, par_status->pos, par_status->dir, par_status->loc_dir);
            break;
        }
        }
    }

    if(!par_status->cell) {     //如果没有找到下一个栅元
        par_status->is_killed = true;
        return;
    }

    cell = par_status->cell;
    fprintf(base_IOfp.neural_fp,"%d\n",cell->rank);
    if(cell->imp == 0)      //如果下个栅元的imp等于0
        par_status->is_killed = true;
    par_status->mat = cell->mat;    //更新材料和温度
    par_status->cell_tmp = cell->tmp;
    par_status->mat_changed = (prev_mat != par_status->mat);
    par_status->cell_tmp_changed = !EQ_ZERO(prev_cell_tmp - par_status->cell_tmp);


}
