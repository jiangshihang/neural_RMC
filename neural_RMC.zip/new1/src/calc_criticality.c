//
// Created by xaq on 10/26/17.
//

#include "criticality.h"
#include "RNG.h"
#include "IO_releated.h"
#include "list.h"


extern criti_t base_criti;
extern IOfp_t base_IOfp;

void
calc_criticality()
{
    init_fission_src();  //初始化裂变源

    particle_status_t par_status;
    for(int cyc = 1; cyc <= base_criti.tot_cycle_num; cyc++) {      //对于每一代中子
        list_t *data_per_cycle = list_init();  //建立存储这一代粒子数据的链表

        for(int neu = 1; neu <= base_criti.cycle_neutron_num; neu++) {      //对于每一代中的每一个中子
            if(cyc > base_criti.inactive_cycle_num && neu!=1)
              system("rm neutron_neural.csv");  //删除上个循环遗留下来的.csv文件

            get_rand_seed();

            /* sample source particle */
            sample_fission_src(&par_status);    //抽样获取初始源的位置
            if(cyc > base_criti.inactive_cycle_num)
              strcpy(base_IOfp.neural_data, "neurton_neural.csv");
              //printf("this is cyc %d, neu %d\n",cyc,neu);
            /* neutron history */
            track_history(&par_status, cyc);  //追踪中子历史

            listnode_insert(&data_per_cycle, &par_status);  //将中子信息数据插入链表中
            if(cyc > base_criti.inactive_cycle_num)
              fprintf(base_IOfp.neural_fp, "%f,%f,%f,%f,%f,%f,%f,",par_status->loc_pos[0],par_status->loc_pos[1],par_status->loc_pos[2],
                par_status->dir[0],par_status->dir[1],par_status->dir[2],par_status->erg);  //在文件中输出这些数据
        }

        while(data_per_cycle->header->succ!=data_per_cycle->trailer){
          listnode_t *current_neutron = data_per_cycle->header;

          if(cyc > base_criti.inactive_cycle_num)  //如果粒子处于活跃代
            system("python load_model.py");  //调用python脚本，在脚本中调用模型对粒子数据集中进行处理

          while(current_neutron->succ){  //当未到达最后一个中子时
            track_history(&current_neutron, cyc);

            current_neutron = current_neutron->succ;  //指针指向下一个neutron
          }

          if(cyc > base_criti.inactive_cycle_num)
            system("rm neutron_neural.csv");

          if(cyc > base_criti.inactive_cycle_num){  //对于需要利用神经网络预测的中子
            strcpy(base_IOfp.neural_data, "neurton_neural.csv");
            fprintf(base_IOfp.neural_fp, "%f,%f,%f,%f,%f,%f,%f,",par_status->loc_pos[0],par_status->loc_pos[1],par_status->loc_pos[2],
              par_status->dir[0],par_status->dir[1],par_status->dir[2],par_status->erg);  //在文件中输出这些数据
          }
        }

        process_cycle_end(cyc);  //每一代结束后处理相关数据
    }
    output_summary();
}
